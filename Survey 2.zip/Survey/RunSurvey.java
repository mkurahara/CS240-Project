public class RunSurvey{

    Survey survey;
    SurveyGuiUI gui;

    public static void main(String args[] ){
        Survey survey = new Survey();
        SurveyGuiUI gui = new SurveyGuiUI();

    }
}