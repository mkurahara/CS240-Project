import java.util.ArrayList;

public class Routine{

    //instance variables
    private ArrayList<Exercise> routine = new ArrayList<Exercise>();

    //default constructor
    public Routine(){
        this.routine = null;
    }
    public Routine(ArrayList<Exercise> routine){
        this.routine = routine;
    }

    //public 

    // displays the routine window to the user
    public void display(){

    }

    public ArrayList<Exercise> getRoutine(){
        return this.routine;
    }
    public String toString(){
        return routine.toString();
    }


    
}